<?php

$ipFilter = array('71.236.0.196');
$userFilter = array();